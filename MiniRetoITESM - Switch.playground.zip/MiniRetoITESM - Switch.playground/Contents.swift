//: Playground - noun: a place where people can play

import UIKit

var numero = 1...100
var resultado = 0
var i = 0
var cinco = 0

for i in numero{
    
    resultado = i % 2
    cinco = i % 5
    
    switch i {
    case 1...29:
        if cinco == 0 {
            print ("\(i) Bingo!!!")
        } else if resultado == 0 {
            print ("\(i) par!!!")
        }
            else {
                print ("\(i) impar")
            }
    case 41...100:
        if cinco == 0 {
            print ("\(i) Bingo!!!")
        } else if resultado == 0 {
            print ("\(i) par!!!")
        }
        else {
            print ("\(i) impar")
        }
    default:
        print ("\(i) Viva Swift")
    }
    }

