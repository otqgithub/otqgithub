//: Playground - noun: a place where people can play

import UIKit



enum Velocidades : Int {
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init(velocidadInicial:Velocidades){
        self = velocidadInicial
    }
}

class Auto {
    
    var velocidad = Velocidades (velocidadInicial:.Apagado)
    
    init (){
        self.velocidad = .Apagado
    }
    
    func cambioDeVelocidad() ->(actual:Int,velocidadEnCadena:String){
        
        if velocidad.rawValue < 120{
            while velocidad != .VelocidadAlta {
                switch velocidad.rawValue {
                case 0:
                    let cambio = (velocidad.rawValue, "Apagado")
                    velocidad = .VelocidadBaja
                    return cambio
                case 20:
                    let cambio = (velocidad.rawValue,"Velocidad Baja")
                    velocidad = .VelocidadMedia
                    return cambio
                case 50:
                    let cambio = (velocidad.rawValue, "Velocidad Media")
                    velocidad = .VelocidadAlta
                    return cambio
                case 120:
                    let cambio = (velocidad.rawValue, "Velocidad Alta")
                    velocidad = .VelocidadAlta
                default:
                    break
                    //          return (velocidad.rawValue,"revisar codigo")
                }
            }
        }
        
        if velocidad == .VelocidadAlta {
            switch velocidad {
                case .VelocidadAlta:
                    let cambio = (velocidad.rawValue, "Velocidad Alta")
                    velocidad = .VelocidadMedia
                    return cambio
                case .VelocidadMedia:
                    let cambio = (velocidad.rawValue,"Velocidad Media")
                    velocidad = . VelocidadBaja
                    return cambio
                case .VelocidadBaja:
                    let cambio = (velocidad.rawValue,"Velocidad Baja")
                    velocidad = .Apagado
                    return cambio
                case .Apagado:
                    let cambio = (velocidad.rawValue,"Apagado")
                    return cambio
            }
        }
        
        return (velocidad.rawValue,"Error")
        
    }
    
}


var auto=Auto()
var numero = 1...20
var i = 0

for i in numero {
    
    var impresion = auto.cambioDeVelocidad()
    print (impresion)
}

